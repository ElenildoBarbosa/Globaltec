﻿namespace Projeto_globaltec.Modelos
{
    public interface IPessoa
    {
        IEnumerable<Pessoa> GetAll();
        Pessoa Get(int Codigo);
        Pessoa Get(String UF);
        Pessoa Add(Pessoa item);
        void Remove(int Codigo);
        bool Update(Pessoa item);
    }
}
