﻿using System.Net;
using Projeto_globaltec.Modelos;
using Microsoft.AspNetCore.Mvc;
using System.Web.Http;
using System.Web.Http.Routing;

namespace Projeto_globaltec.Controles
{
    [System.Web.Http.Route("api/[controller]")]
    [ApiController]
    public class PessoasController : ApiController
    {
        static readonly IPessoa repositorio = new PessoaRepositorio();

        public IEnumerable<Pessoa> GetAllPessoas()
        {
            return repositorio.GetAll();
        }

        public Pessoa GetPessoa(int Codigo)
        {
            Pessoa item = repositorio.Get(Codigo);
            if (item == null)
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }
            return item;
        }

        public IEnumerable<Pessoa> GetPessoasPorUF(string UF)
        {
            return repositorio.GetAll().Where(
                p => string.Equals(p.UF, UF, StringComparison.OrdinalIgnoreCase));
        }


        public HttpResponseMessage PostPessoa(Pessoa item)
        {
            item = repositorio.Add(item);
            var response = Request.CreateResponse<Pessoa>(HttpStatusCode.Created, item);
           


            string uri = Url.Link("DefaultApi", new { id = item.Codigo });
            response.Headers.Location = new Uri(uri);
            return response;
        }

        public void PutPessoa(int id, Pessoa pessoa)
        {
            pessoa.Codigo = id;
            if (!repositorio.Update(pessoa))
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }
        }

        public void DeletePessoa(int Codigo)
        {
            Pessoa item = repositorio.Get(Codigo);

            if (item == null)
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }

            repositorio.Remove(Codigo);
        }
                
    }
}
