﻿using System;
using System.Collections.Generic;

namespace Projeto_globaltec.Modelos
{
    public class PessoaRepositorio : IPessoa
    {
        private List<Pessoa> Pessoas = new List<Pessoa>();
        private int _nextId = 1;

        public PessoaRepositorio()
        {
            Add(new Pessoa { Nome = "Elenildo", CPF = 01165719185, UF = "GO", Dt_Nascimento = new DateTime(1986, 03, 22) });
            Add(new Pessoa { Nome = "Driellen", CPF = 1234567899, UF = "DF", Dt_Nascimento = new DateTime(1988, 05, 10) });
            Add(new Pessoa { Nome = "Rafaela", CPF = 78945612366, UF = "RJ", Dt_Nascimento = new DateTime(1996, 07, 15) });
            Add(new Pessoa { Nome = "Henrique", CPF = 14725836988, UF = "PA", Dt_Nascimento = new DateTime(1984, 08, 25) });
            Add(new Pessoa { Nome = "Elvis", CPF = 12365478966, UF = "MG", Dt_Nascimento = new DateTime(1999, 01, 05) });
            Add(new Pessoa { Nome = "Junior", CPF = 98765432144, UF = "SP", Dt_Nascimento = new DateTime(1965, 11, 07) });
        }

        public Pessoa Add(Pessoa item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            item.Codigo = _nextId++;
            Pessoas.Add(item);
            return item;
        }

        public Pessoa Get(int Codigo)
        {
            return Pessoas.Find(p => p.Codigo == Codigo);
        }

        public Pessoa Get(string UF)
        {
            return Pessoas.Find(p => p.UF == UF);
        }

        public IEnumerable<Pessoa> GetAll()
        {
            return Pessoas;
        }

        public void Remove(int Codigo)
        {
            Pessoas.RemoveAll(p => p.Codigo == Codigo);
        }

        public bool Update(Pessoa item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }

            int index = Pessoas.FindIndex(p => p.Codigo == item.Codigo);

            if (index == -1)
            {
                return false;
            }
            Pessoas.RemoveAt(index);
            Pessoas.Add(item);
            return true;
        }
    }
}
