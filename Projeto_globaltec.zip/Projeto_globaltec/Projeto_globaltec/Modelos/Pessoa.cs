﻿namespace Projeto_globaltec.Modelos
{
    public class Pessoa
    {
        public int Codigo { get; set; }
        public string Nome { get; set; }
        public Int64 CPF { get; set; }
        public string UF { get; set; }
        public DateTime Dt_Nascimento { get; set; }

    }
}
